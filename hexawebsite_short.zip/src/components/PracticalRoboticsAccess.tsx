
import React from 'react';
import { ArrowRight, Cpu, Monitor, Network, Orbit } from 'lucide-react';

export const PracticalRoboticsAccess: React.FC = () => {
  return (
    <section className="py-24 bg-hexa-bg relative overflow-hidden border-b border-gray-900">
      {/* Background Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-hexa-purple/5 rounded-full blur-[120px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div className="space-y-8">
             <h2 className="text-white font-mono-plex font-bold uppercase text-sm tracking-widest">The HexaKinetica Platform</h2>
             <h3 className="font-display text-3xl md:text-5xl text-white uppercase leading-tight">
                 One Platform. <br /> <span className="text-gray-500">Two Robot Arm Lines.</span>
             </h3>
             <p className="text-lg text-gray-400 font-mono-plex leading-relaxed">
                 Maker and Industrial robot arm lines are developed from the same platform foundation: mechanical design, motion control, operator software, simulation workflow, and engineering documentation.
                <br/><br/>
                 <span className="text-white font-bold">HexaKinetica</span> is building a practical robot arm platform that can scale from accessible development hardware to more capable industrial-oriented systems.
             </p>

             <div className="pt-4">
                <h4 className="font-display text-2xl text-white uppercase mb-4">HexaCore Motion Architecture</h4>
                <p className="text-base text-gray-400 font-mono-plex leading-relaxed mb-6">
                  HexaCore is the motion-control foundation behind the HexaKinetica platform. It connects robot arm hardware, motor drives, operator software, and simulation into one practical workflow for testing, validation, and operation.
                  <br/><br/>
                  The same architecture supports both platform directions: accessible Maker systems for development and education, and Industrial systems built around stronger mechanics, EtherCAT motion, and integration-oriented control.
                </p>
                <button className="inline-flex items-center text-white font-mono-plex text-xs font-bold uppercase tracking-widest border-b border-hexa-purple pb-1 hover:text-hexa-purple transition-colors">
                  SEE PLATFORM STACK
                  <ArrowRight size={14} className="ml-2" />
                </button>
             </div>
          </div>

          {/* Platform + lines */}
          <div className="bg-hexa-card backdrop-blur-md border border-hexa-purple/30 rounded-xl p-8 shadow-2xl relative">
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-hexa-cyan/10 rounded-full blur-xl"></div>
            
            <h4 className="font-display text-2xl text-left mb-8 uppercase tracking-widest">Shared Platform Core</h4>

            <div className="space-y-4 mb-8">
              {[
                { icon: Network, title: 'EtherCAT Motion Layer', text: 'industrial fieldbus for coordinated motor control' },
                { icon: Cpu, title: 'Robot Control Runtime', text: 'motion logic, trajectory execution, and device communication' },
                { icon: Monitor, title: 'Operator Software', text: 'configuration, calibration, testing, and diagnostics' },
                { icon: Orbit, title: 'Simulation Bridge', text: 'validation workflow connected to real robot hardware' },
              ].map(({ icon: Icon, title, text }) => (
                <div key={title} className="flex items-start space-x-4 border border-white/5 rounded-xl p-4 bg-black/20">
                  <div className="bg-hexa-purple/10 border border-hexa-purple/20 p-3 rounded-lg shrink-0">
                    <Icon className="text-hexa-purple" size={20} />
                  </div>
                  <div>
                    <h5 className="text-white font-display text-base mb-1">{title}</h5>
                    <p className="text-gray-500 font-mono-plex text-sm leading-relaxed">{text}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-gray-800 pt-8">
              <div>
                <h5 className="font-display text-xl text-white uppercase mb-3">Maker Line</h5>
                <p className="text-gray-400 font-mono-plex text-sm leading-relaxed mb-4">
                  Accessible robot arm hardware for robotics development, education, software testing, and prototyping.
                </p>
                <p className="text-gray-500 font-mono-plex text-sm leading-relaxed">
                  <span className="text-white">Focus:</span> learning, testing, modification, affordability, open development workflow.
                </p>
              </div>
              <div>
                <h5 className="font-display text-xl text-white uppercase mb-3">Industrial Line</h5>
                <p className="text-gray-400 font-mono-plex text-sm leading-relaxed mb-4">
                  More capable robot arm hardware built around industrial motion components, stronger mechanics, and integration-oriented control architecture.
                </p>
                <p className="text-gray-500 font-mono-plex text-sm leading-relaxed">
                  <span className="text-white">Focus:</span> EtherCAT motion, industrial motors, cabinet-based control, validation hardware, early automation development.
                </p>
              </div>
            </div>
            
            <div className="mt-8 text-center">
                <p className="text-sm text-gray-500 font-mono-plex italic">"A practical path into robot arm hardware, motion control, software, and simulation."</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
